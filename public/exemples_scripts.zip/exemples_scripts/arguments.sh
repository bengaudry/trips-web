#!/bin/bash

echo le nom du script est $0
echo $# arguments lui ont été donnés :
echo le premier argument est $1
echo le deuxième argument est $2
echo le troisième argument est $3
echo ...
