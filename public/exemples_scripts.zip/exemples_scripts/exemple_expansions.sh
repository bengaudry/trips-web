#!/bin/bash

truc=FINI
echo * $truc
echo
echo "* $truc"
echo
echo '* $truc'
echo
echo \* \$truc
