#!/bin/bash

echo Sans substitution on écrit expr 7 + 6

echo Avec substitution on écrit $(expr 7 + 6)

echo Sans expr ça ne marche pas : 7 + 6 donne $(7 + 6)
