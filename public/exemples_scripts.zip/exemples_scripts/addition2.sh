#!/bin/bash

read A
read B
expr $A + $B
