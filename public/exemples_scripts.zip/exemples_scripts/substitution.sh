#!/bin/bash

REP=$(pwd)
echo Nous sommes actuellement dans le répertoire $REP

cd ~
echo Voici le contenu du répertoire principal : $(ls)

cd $REP
echo Et nous revoilà dans $REP qui contient : $(ls)
