#!/bin/bash

NOM=Wack
PRENOM=Benjamin

REP=inf203

echo Bonjour $PRENOM $NOM

ls ~/$REP
